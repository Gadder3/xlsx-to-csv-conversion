package com.example.Excel2Json;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Excel2JsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
