package com.example.Excel2Json;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;

@RestController
public class ExcelController {

	@PostMapping("excel")
	public String getExcel(@RequestParam("data") MultipartFile data) {
		excel2Json(data);
		return "Success";
	}
	
	public void excel2Json(MultipartFile data) {
		try {
			XSSFWorkbook workBook = new XSSFWorkbook(data.getInputStream());
			XSSFSheet workSheet = workBook.getSheetAt(0);
			List<JSONObject> dataList = new ArrayList<>();
			XSSFRow header = workSheet.getRow(0); 
			for(int i=1;i<workSheet.getPhysicalNumberOfRows();i++) {
				XSSFRow row = workSheet.getRow(i);
				JSONObject rowJsonObject = new JSONObject();
				for(int j=0; j<row.getPhysicalNumberOfCells();j++) {
					String columnName = header.getCell(j).toString();
					String columnValue = row.getCell(j).toString();
					rowJsonObject.put(columnName, columnValue);
				}
				dataList.add(rowJsonObject);
			}
			System.out.println(dataList);
			writeData2JsonFile(dataList);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void writeData2JsonFile(List<JSONObject> dataList) {
		Gson gson = new Gson();
		try {
			FileWriter file = new FileWriter("C:\\Users\\user\\Downloads\\Excel2Json\\src\\main\\resources\\data.json");
			file.write(gson.toJson(dataList));
			file.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
