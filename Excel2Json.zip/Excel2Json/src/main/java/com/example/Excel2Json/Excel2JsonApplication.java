package com.example.Excel2Json;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Excel2JsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(Excel2JsonApplication.class, args);
	}

}
